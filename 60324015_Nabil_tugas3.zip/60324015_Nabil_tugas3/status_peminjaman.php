<?php
// ============================================
// SISTEM STATUS PEMINJAMAN PERPUSTAKAAN
// ============================================

// --- Data Anggota ---
$nama_anggota = "Budi Santoso";
$total_pinjaman = 2;
$buku_terlambat = 1;
$hari_keterlambatan = 5; // hari

// --- Konstanta Aturan ---
$maks_pinjam = 3;
$denda_per_hari = 1000; // Rp 1.000/hari/buku
$maks_denda = 50000;    // Rp 50.000

// --- Hitung Denda ---
$total_denda = $buku_terlambat * $hari_keterlambatan * $denda_per_hari;
if ($total_denda > $maks_denda) {
    $total_denda = $maks_denda;
}

// --- IF-ELSEIF-ELSE: Cek status peminjaman ---
if ($buku_terlambat > 0) {
    $status_pinjam = "TIDAK BISA PINJAM - Ada buku terlambat dikembalikan";
    $bisa_pinjam = false;
} elseif ($total_pinjaman >= $maks_pinjam) {
    $status_pinjam = "TIDAK BISA PINJAM - Kuota peminjaman penuh ($maks_pinjam buku)";
    $bisa_pinjam = false;
} else {
    $sisa_kuota = $maks_pinjam - $total_pinjaman;
    $status_pinjam = "BISA PINJAM - Sisa kuota: $sisa_kuota buku";
    $bisa_pinjam = true;
}

// --- SWITCH: Tentukan level member ---
switch (true) {
    case ($total_pinjaman > 15):
        $level_member = "Gold";
        $warna_level = "gold";
        break;
    case ($total_pinjaman >= 6):
        $level_member = "Silver";
        $warna_level = "silver";
        break;
    default:
        $level_member = "Bronze";
        $warna_level = "#cd7f32";
        break;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Peminjaman - Perpustakaan</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            color: #e0e0e0;
        }

        .container {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 40px;
            max-width: 600px;
            width: 100%;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        h1 {
            text-align: center;
            font-size: 1.6rem;
            margin-bottom: 30px;
            color: #e94560;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .card {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .card h2 {
            font-size: 1rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 15px;
            color: #53d8fb;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            padding-bottom: 8px;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px dashed rgba(255, 255, 255, 0.08);
        }

        .info-row:last-child {
            border-bottom: none;
        }

        .info-label {
            color: #aaa;
        }

        .info-value {
            font-weight: 600;
            color: #fff;
        }

        .badge {
            display: inline-block;
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 700;
            letter-spacing: 1px;
        }

        .badge-level {
            border: 2px solid;
        }

        .status-box {
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            font-weight: 600;
            font-size: 1rem;
            letter-spacing: 0.5px;
        }

        .status-ok {
            background: rgba(0, 200, 83, 0.15);
            border: 1px solid rgba(0, 200, 83, 0.4);
            color: #69f0ae;
        }

        .status-blocked {
            background: rgba(233, 69, 96, 0.15);
            border: 1px solid rgba(233, 69, 96, 0.4);
            color: #ff6b6b;
        }

        .warning-box {
            background: rgba(255, 193, 7, 0.12);
            border: 1px solid rgba(255, 193, 7, 0.3);
            border-radius: 10px;
            padding: 15px;
            margin-top: 10px;
            color: #ffd54f;
            font-size: 0.9rem;
        }

        .warning-box .icon {
            margin-right: 6px;
        }

        .denda-highlight {
            color: #ff6b6b;
            font-size: 1.2rem;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📚 Status Peminjaman</h1>

        <!-- Informasi Anggota -->
        <div class="card">
            <h2>👤 Informasi Anggota</h2>
            <div class="info-row">
                <span class="info-label">Nama</span>
                <span class="info-value"><?= htmlspecialchars($nama_anggota) ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Total Pinjaman</span>
                <span class="info-value"><?= $total_pinjaman ?> buku</span>
            </div>
            <div class="info-row">
                <span class="info-label">Level Member</span>
                <span class="info-value">
                    <span class="badge badge-level" style="color: <?= $warna_level ?>; border-color: <?= $warna_level ?>;">
                        <?= $level_member ?>
                    </span>
                </span>
            </div>
        </div>

        <!-- Status Peminjaman -->
        <div class="card">
            <h2>📋 Status Peminjaman</h2>
            <div class="status-box <?= $bisa_pinjam ? 'status-ok' : 'status-blocked' ?>">
                <?= $bisa_pinjam ? '✅' : '🚫' ?> <?= $status_pinjam ?>
            </div>

            <?php if ($buku_terlambat > 0): ?>
                <div class="warning-box">
                    <span class="icon">⚠️</span>
                    <strong>Peringatan Keterlambatan!</strong><br><br>
                    Anda memiliki <strong><?= $buku_terlambat ?> buku</strong> yang terlambat dikembalikan selama <strong><?= $hari_keterlambatan ?> hari</strong>.<br>
                    Segera kembalikan buku agar dapat meminjam kembali.
                </div>
            <?php endif; ?>
        </div>

        <!-- Informasi Denda -->
        <div class="card">
            <h2>💰 Informasi Denda</h2>
            <?php if ($buku_terlambat > 0): ?>
                <div class="info-row">
                    <span class="info-label">Buku Terlambat</span>
                    <span class="info-value"><?= $buku_terlambat ?> buku</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Lama Keterlambatan</span>
                    <span class="info-value"><?= $hari_keterlambatan ?> hari</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Tarif Denda</span>
                    <span class="info-value">Rp <?= number_format($denda_per_hari, 0, ',', '.') ?>/hari/buku</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Perhitungan</span>
                    <span class="info-value"><?= $buku_terlambat ?> × <?= $hari_keterlambatan ?> × Rp <?= number_format($denda_per_hari, 0, ',', '.') ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Total Denda</span>
                    <span class="denda-highlight">Rp <?= number_format($total_denda, 0, ',', '.') ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Maksimal Denda</span>
                    <span class="info-value">Rp <?= number_format($maks_denda, 0, ',', '.') ?></span>
                </div>
            <?php else: ?>
                <p style="text-align: center; color: #69f0ae; padding: 10px;">✅ Tidak ada denda. Semua buku dikembalikan tepat waktu.</p>
            <?php endif; ?>
        </div>

        <!-- Ringkasan Aturan -->
        <div class="card">
            <h2>📖 Ringkasan Aturan</h2>
            <div class="info-row">
                <span class="info-label">Maks. Peminjaman</span>
                <span class="info-value"><?= $maks_pinjam ?> buku</span>
            </div>
            <div class="info-row">
                <span class="info-label">Denda Keterlambatan</span>
                <span class="info-value">Rp <?= number_format($denda_per_hari, 0, ',', '.') ?>/hari/buku</span>
            </div>
            <div class="info-row">
                <span class="info-label">Maks. Denda</span>
                <span class="info-value">Rp <?= number_format($maks_denda, 0, ',', '.') ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Level Bronze</span>
                <span class="info-value">0–5 peminjaman</span>
            </div>
            <div class="info-row">
                <span class="info-label">Level Silver</span>
                <span class="info-value">6–15 peminjaman</span>
            </div>
            <div class="info-row">
                <span class="info-label">Level Gold</span>
                <span class="info-value">>15 peminjaman</span>
            </div>
        </div>
    </div>
</body>
</html>
